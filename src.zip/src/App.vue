<template>
  <!-- <img alt="Vue logo" src="./assets/logo.png"> -->
  <!-- <HelloWorld msg="Welcome to Your Vue.js App"/> -->
  <h1>{{mydata}}</h1>
  <HomeView data="This is Vue"/>
  <HomeBind/>
</template>

<script>
//import HelloWorld from './components/HelloWorld.vue'
import HomeView from './components/home.vue'
import HomeBind from './components/databind.vue'
export default {
  name: 'App',
  components: {
    //HelloWorld,
    HomeView,
    HomeBind
  },
  data() {
    return {
      mydata:"Props transfer"
    }
  },
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
