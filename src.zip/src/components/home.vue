<template>
<div>
    <p v-html="header" class="vuestyle" ></p>
    <h1 v-if="a" v-bind:class="{vuestyle:a}"> Home Component</h1>
    <h3 v-else v-bind:style="{color:colourname}"> Its me</h3>
    <h2>{{data1}}</h2>
    <button v-on:click="hello('data1')" v-on:mouseover="display" v-bind:style="{color:'Red'}"> Click Me</button>
    <table v-bind:class="[d,v]" style="border: 1px solid black;">
        <tr>
            <td style="border: 1px solid black;"> Javascript Framework/Library</td>
            <td style="border: 1px solid black;">Company</td>
        </tr>
        <tr v-for="js in jscripts" :key="js.id">
        <td style="border: 1px solid black;">{{js.jscript}}</td>
        <td style="border: 1px solid black;">{{js.Createby}}</td>
        </tr>
    </table>
    
</div>
</template>
<script>
export default {
   name:'HomeView',
   props:{
       data1:String
   },
   data() {
       return {
           a:true,
           header:"<h2>I am Vue</h2>",
           colourname:'darkblue',
           jscripts:[
                   {id:1,jscript:'React',Createby:'Facebook'},
                    {id:2,jscript:'Vue',Createby:'Google'},
                     {id:3,jscript:'Angular',Createby:'Google'}
               ],
               d:'vuestyle',
               v:'vuestyle2'
       }
   },
   methods:{
       hello(item)
       {
           alert("Hello Vue"+' '+item)
       },
       display()
       {
           this.a=!this.a
       }
    
   }
   
}
</script>
<style scoped>
.vuestyle{
    color:orange
}
.vuestyle2{
    background-color: antiquewhite
}
</style>
