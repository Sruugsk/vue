<template>
<div>
    <h1>{{message}}</h1>
    <input type="text" v-model="message"/>
</div>
</template>
<script>
export default {
   name:'HomeBind',
   data() {
       return {
           message:'Databind'
       }
   },
   created()
   {
      console.log("Created")
   },
   beforeCreate()
   {
    console.log("Onway")
   }
}
</script>


